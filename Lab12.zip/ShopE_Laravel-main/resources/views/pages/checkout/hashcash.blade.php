@extends('layout')
@section('content')
   <h3 style="display: flex;justify-content: center;align-items: center"> Cảm ơn bạn đã đặt hàng ! Chúng tôi sẽ liên hệ lại cho bạn dựa trên thông tin bạn đã cung cấp.</h3>
@endsection