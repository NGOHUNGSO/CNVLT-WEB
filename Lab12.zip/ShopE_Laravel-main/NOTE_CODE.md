## About Laravel
> Lệnh Tạo Bảng 
 Lệnh : php artisan make:migration {tab name in file php} --create={tab name in database}
 VD : php artisan make:migration tbl_slider --create=tbl_slider
 Ghi Bảng Vào Database : php artisan migrate

 > Lệnh Tạo Model
 Lệnh : php artisan make:model {model name in file php}
 VD :  php artisan make:model Coupon

  > Lệnh Tạo Model
 Lệnh : php artisan make:controller {model name in file php}
 VD :  php artisan make:controller DeliveryController